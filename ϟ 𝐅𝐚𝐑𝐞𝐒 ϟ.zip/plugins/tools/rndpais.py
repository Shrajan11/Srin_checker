import requests 
from pyrogram import Client, filters
from pyrogram.types import Message
from pulpos.plantillas import _cmdbotons, _cmd

@Client.on_message(filters.command("rnd"))
async def cmds(client, message):
    with open(file='plugins/usuarios/users.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x:
            zipcode = message.text[len('/ip '):]
            if not zipcode:
               await message.reply("<b>ϟ Usar <code>/rnd ca</code></b>")
            
            api = requests.get(f"https://randomuser.me/api/?nat={zipcode}&inc=name,location").json()

            mr = api["results"][0]["name"]["title"]
            nombre = api["results"][0]["name"]["first"]
            last = api["results"][0]["name"]["last"]
            loca = api["results"][0]["location"]["street"]["name"]
            nm = api["results"][0]["location"]["street"]["number"]
            city = api["results"][0]["location"]["city"]
            state = api["results"][0]["location"]["state"]
            country = api["results"][0]["location"]["country"]
            postcode = api["results"][0]["location"]["postcode"]
            latitude = api["results"][0]["location"]["coordinates"]["latitude"]
            longitude = api["results"][0]["location"]["coordinates"]["longitude"]
            
            await message.reply(f"""
        <b> 
♦ 𝐅𝐚𝐤𝐞 𝐀𝐝𝐝𝐫𝐞𝐬𝐬 🥀
♦ 𝑵𝒂𝒎𝒆: <code>{mr} {nombre} {last}</code>
♦ 𝑺𝒕𝒓𝒆𝒆𝒕:  <code>{state}</code>
♦ 𝑪𝒊𝒕𝒚: <code>{city}</code>
♦ 𝑺𝒕𝒂𝒕𝒆:<code> {loca} {nm}</code>
♦ 𝒁𝒊𝒑: <code> {postcode}</code>
♦ 𝑪𝒐𝒖𝒏𝒕𝒓𝒚: <code>{country}</code>
♦ 𝑪𝒉𝒆𝒌𝒆𝒅 𝑩𝒀: <code> @{message.from_user.username}[Free User]</code>
━━━━━━━━━━━━━━
♦𝐁𝐨𝐭 𝐃𝐞𝐕: <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
♦ 𝐆𝐑 : <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b>
 </b>""")
        else:
            return await message.reply(f'<b>ϟ Registrese <code>/register</code></b>')
    