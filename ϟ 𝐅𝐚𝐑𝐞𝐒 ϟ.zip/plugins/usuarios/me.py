from pyrogram import Client, filters
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
)

@Client.on_message(filters.command(["me","yo","my","myacc"], ["/", "."]))
async def register(_, m: Message):
    user=m.from_user.first_name
    user_id =m.from_user.id
    seller = [1395727975]


    admin = [5166848362]
    
    if m.from_user.id in seller or m.from_user.id in seller:
        await m.reply(f"""<b>
ϟ 🕊 𝘜𝘴𝘦𝘳 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯 🕊

ϟ 𝑵𝒂𝒎𝒆            <code>{user} </code>
ϟ 𝑰𝑫                   <code>{user_id}</code>
ϟ 𝑪𝒓𝒆𝒅𝒊𝒕𝒔           <code>9999</code>
ϟ 𝑺𝒕𝒂𝒕𝒖𝒔           <code>𝘊𝘳𝘦𝘢𝘥𝘰𝘳  [ 🥀 ]</code>
ϟ 𝑷𝒍𝒂𝒏               <code>𝘋𝘪𝘢𝘮𝘢𝘯𝘵𝘦  [ ❌ ]</code>
━━━━━━━━━━━━━━━━━━━━━━
ϟ 𝐁𝐨𝐭 𝐃𝐞𝐕 : <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
ϟ 𝐆𝐑 : <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b>
    </b>""")
    elif m.from_user.id in admin:
        await m.reply(f"""<b>
ϟ 𝘜𝘴𝘦𝘳 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯 

ϟ 𝑵𝒂𝒎𝒆           <code>{user} </code>
ϟ 𝑰𝑫                <code> {user_id}</code>
ϟ 𝑪𝒓𝒆𝒅𝒊𝒕𝒔              <code>1050</code>
ϟ 𝑺𝒕𝒂𝒕𝒖𝒔          <code>𝘈𝘥𝘮𝘪𝘯𝘴 </code>
ϟ 𝑷𝒍𝒂𝒏              <code>𝘝𝘪𝘱  🌩</code>
━━━━━━━━━━━━━━━━━━━━━━
ϟ 𝐁𝐨𝐭 𝐃𝐞𝐕 : <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
ϟ 𝐆𝐑 : <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b>
    </b>""")
     
    else:
       
        with open(file='plugins/usuarios/premium.txt',mode='r+',encoding='utf-8') as archivo:
            x = archivo.readlines()

            if str(m.from_user.id) + '\n' in x:            
                await m.reply(f"""<b>
ϟ 🕊 𝘜𝘴𝘦𝘳 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯 🕊

ϟ 𝑵𝒂𝒎𝒆              <code>{user} </code>
ϟ 𝑰𝑫                   <code> {user_id}</code>
ϟ 𝑪𝒓𝒆𝒅𝒊𝒕𝒔              <code>500</code>
ϟ 𝑺𝒕𝒂𝒕𝒖𝒔             <code>𝘗𝘭𝘢𝘯  P</code>
ϟ 𝑷𝒍𝒂𝒏                 <code>𝘗𝘳𝘦𝘮𝘪𝘶𝘮 🤍🕊</code>
━━━━━━━━━━━━━━━━━━━━━━
ϟ 𝐁𝐨𝐭 𝐃𝐞𝐕: <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
ϟ 𝐆𝐑: <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b>
            </b>""")
                    
            else:
                await m.reply(f"""<b>
ϟ 🕊 𝘜𝘴𝘦𝘳 𝘐𝘯𝘧𝘰𝘳𝘮𝘢𝘵𝘪𝘰𝘯 🕊

ϟ 𝑵𝒂𝒎𝒆              <code>{user} </code>
ϟ 𝑰𝑫                   <code> {user_id}</code>
ϟ 𝑪𝒓𝒆𝒅𝒊𝒕𝒔              <code>12</code>
ϟ 𝑺𝒕𝒂𝒕𝒖𝒔             <code>𝘜𝘴𝘦𝘳 </code>
ϟ 𝑷𝒍𝒂𝒏                 <code>𝘍𝘳𝘦𝘦  🌧</code>
━━━━━━━━━━━━━━━━━━━━━━
ϟ 𝐁𝐨𝐭 𝐃𝐞𝐕 : <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
ϟ 𝐆𝐑: <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b>
    </b>""")