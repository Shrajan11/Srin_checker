import time
from pyrogram import Client, filters
from pyrogram.types import Message
from inc.checker import checkear
from gate import str
from datos import idchat

@Client.on_message(filters.command("str"))
async def str(client, message):

    data = message.text
    try:        
        data = data.split(" ", maxsplit= 1)[1]
    except Exception:
        await message.reply_text("<b>ϟ  Usar <code>/str card</code></b>")
        return

    await checkear(str, data, client, message)

      