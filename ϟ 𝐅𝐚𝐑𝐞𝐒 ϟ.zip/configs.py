from os import path, getenv

class Config:
    API_ID = int(getenv('API_ID','20679106'))
    API_HASH = getenv('API_HASH','8d3004a6d520d3c6983ff520b15a8f93')
    BOT_TOKEN = getenv('BOT_TOKEN','6861815176:AAGwSt5fmCGTQwl8ToweQoqiaCrMlbStHUs')

config = Config()
