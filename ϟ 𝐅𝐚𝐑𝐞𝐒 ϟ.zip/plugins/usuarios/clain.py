import random
from pyrogram import Client, filters

from datos import admin

FILE_PATH = "plugins/usuarios/keys.txt"

app = Client

@app.on_message(filters.command("claim",["/", "."]))
async def claim_key(client, message):
    with open(file='plugins/usuarios/users.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x:

            zipcode = message.text[len('/claim '):]
            
            if len(zipcode) < 2:
                    return await message.reply("<b>ϟ Usar <code>/claim BSLINUX -3739-xxxxx</code></b>")
            if not zipcode:
                return await message.reply("<b>ϟ Usar <code>/claim BSLINUX -3739-xxxxx</code></b>")
                
            with open(FILE_PATH, "r") as f:
                keys = f.read().splitlines()

            key = keys.pop(random.randint(0, len(keys)-1))
            print(key+' 𝑨𝒑𝒑𝒓𝒐𝒗𝒆𝒅')
        

            if len(keys) == 0:
                await message.reply("<b>ϟ 𝑲𝒆𝒚 𝑻𝒂𝒌𝒆𝒏 𝑩𝒚 𝑨𝒏𝒐𝒕𝒉𝒆𝒓 𝑼𝒔𝒆𝒓.</b>")
                return

            
            with open(FILE_PATH, "w") as f:
                f.write("\n".join(keys))


            with open(file='plugins/usuarios/premium.txt',mode='r+',encoding='utf-8') as archivo:
                        x = archivo.readlines()
                        
                        archivo.write('{}\n'.format(message.from_user.id))

            text=f"""<b>
♦ 𝘗𝘳𝘦𝘮𝘪𝘶𝘮 𝘗𝘭𝘢𝘯

♦ 𝑺𝒕𝒂𝒕𝒖𝒔             𝑲𝒆𝒚 𝑨𝒑𝒓𝒐𝒗𝒂𝒅𝒂 ✓
♦ 𝑲𝒆𝒚             <code>•𝐅𝐚𝐑𝐞𝐬 𝑪𝒄 𝑪𝒍𝒂𝒊𝒎•</code>
♦ 𝑼𝒔𝒆𝒓      <code>{message.from_user.first_name} </code>
♦ 𝑰𝑫              <code> {message.from_user.id}</code> 
♦ 𝑺𝒕𝒂𝒕𝒖𝒔      <code>𝑷𝑹𝑬𝑴𝑰𝑼𝑴 🕊</code>  
♦ 𝑪𝒓𝒆𝒅𝒊𝒕𝒔        <code>500</code>
♦ 𝑻𝒂𝒌𝒆𝒏   <code>0.1 s</code>
━━━━━━━━━━
♦ 𝐁𝐨𝐭 𝐃𝐞𝐕: <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
♦𝐆𝐑: <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b></b>"""
            await client.send_photo(message.chat.id, "https://imgur.com/a/ix0cNMv" , f'{text}')
        
        else:
            return await message.reply(f'<b>ϟ Registrese <code>/register</code></b>')
    



