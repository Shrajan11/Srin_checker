import requests 
from pyrogram import Client, filters
from pyrogram.types import Message
from pulpos.plantillas import _cmdbotons, _cmd

@Client.on_message(filters.command("bin"))
async def cmds(client, message):
    with open(file='plugins/usuarios/users.txt',mode='r+',encoding='utf-8') as archivo:
        x = archivo.readlines()
        if str(message.from_user.id) + '\n' in x:
            BIN = message.text[len("/bin"): 11]

            if len(BIN) < 7:
                return await message.reply("<b>⎚ Usar <code>/bin 456789</code></b>")
            if not BIN:
                return await message.reply("<b>⎚ Usar <code>/bin 456789</code></b>")
            inputm = message.text.split(None, 1)[1]
            bincode = 6
            BIN = inputm[:bincode]
            req = requests.get(f"https://bins.antipublic.cc/bins/{BIN}").json()
            if 'bin' not in req:
                await message.reply_text(f'<b>⎚ 𝑩𝒊𝒏 ⇾ 𝑵𝒐𝒕 𝑭𝒐𝒖𝒏𝒅 <code>{BIN} ❌</code></b>')
                
            else:
                brand = req['brand']
                country = req['country']
                country_name = req['country_name']
                country_flag = req['country_flag']
                country_currencies = req['country_currencies']
                bank = req['bank']
                level = req['level']
                typea  = req['type']

                await message.reply_text(f"""
               <b>
ϟ 𝑩𝒊𝒏 ⇾  <code>{BIN}</code>  <b>{country}|{country_flag}|{country_name}</b>

<b>ϟ 𝑺𝒕𝒂𝒕𝒖𝒔 ⇾ Aprovado ✅</b>
ϟ 𝑫𝒂𝒕𝒂 ⇾ {brand}-{typea}-{level}
<b>ϟ 𝑩𝒂𝒏𝒌</b> ⇾  {bank}

<b>ϟ 𝑻𝒂𝒌𝒆 </b>⇾<code> 1.6</code> (segund)
━━━━━━━━━━━━━━━━━━━━━━
ϟ 𝐁𝐨𝐭 𝐃𝐞𝐕 : <b><a href="tg://resolve?domain=Was_FaReS">ϟ 𝐅𝐚𝐑𝐞𝐒 ϟ</a></b>
ϟ 𝐆𝐑 : <b><a href="tg://resolve?domain=CRKSOO_CC7">⏤͟͞S ✘</a></b>
</b>
                """)
    
        else:
            return await message.reply(f'<b>⎚ Registrese <code>/register</code></b>')
    